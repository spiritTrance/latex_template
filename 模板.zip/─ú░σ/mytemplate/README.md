TODO：

- add keyboard shortcut setting.json

- introduce the usage of template